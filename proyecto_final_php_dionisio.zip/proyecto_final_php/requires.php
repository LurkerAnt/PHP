<?php

require_once ('funciones.php');
require_once ('personaje.php');
require_once ('sesiones.php');
require_once ('conexion.php');
require_once ('metodosCrud.php');
require_once ('battleBackEnd.php');

?>